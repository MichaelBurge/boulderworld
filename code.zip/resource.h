//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by yugioh.rc
//
#define IDC_MYICON                      2
#define IDD_YUGIOH_DIALOG               102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_YUGIOH                      107
#define IDI_SMALL                       108
#define IDC_YUGIOH                      109
#define IDC_BOULDER                     109
#define IDR_MAINFRAME                   128
#define IDD_OPTIONS                     134
#define IDD_SWITCHTILES                 137
#define IDD_SAVE                        139
#define IDD_LOAD                        140
#define IDD_TOOLBAR                     141
#define IDB_FILL                        144
#define IDB_SINGLE                      145
#define IDC_WIDTH                       1005
#define IDC_HEIGHT                      1006
#define IDC_FROM                        1010
#define IDC_TO                          1011
#define IDC_FILE                        1012
#define IDC_NEXT                        1015
#define IDC_GRAVITY                     1019
#define IDC_LAVA                        1020
#define IDC_ROCK                        1021
#define IDC_FILL                        1023
#define IDC_SINGLE                      1024
#define IDC_SLOWDOWN                    1025
#define IDM_NEW                         32772
#define IDM_EDITOR_GRASS                32773
#define IDM_EDITOR_BLANK                32774
#define IDM_EDITOR_BOULDER              32775
#define IDM_EDITOR_FLOOD                32776
#define IDM_MAP                         32777
#define IDM_SAVE                        32778
#define IDM_LOAD                        32779
#define IDM_EDITOR_PLAYER               32780
#define IDM_RUN                         32781
#define IDM_EDITOR_SPIKEWALL            32782
#define IDM_OPTIONS                     32783
#define IDM_EDITOR_DIAMOND              32785
#define IDM_EDITOR_FIRE                 32786
#define IDM_EDITOR_SWITCHTILES          32787
#define IDM_REDRAW                      32788
#define IDM_EDITOR_BOMB                 32789
#define IDM_EDITOR_BOMBONFIRE           32790
#define IDM_EDITOR_FUNGUS               32791
#define IDM_EDITOR_DARKFUNGUS           32792
#define IDM_EDITOR_TRANSPORTRIGHT       32794
#define IDM_EDITOR_TRANSPORTLEFT        32796
#define IDM_EDITOR_TRANSPORTUP          32797
#define IDM_EDITOR_TRANSPORTDOWN        32798
#define IDM_EDITOR_BRICKWALL            32799
#define IDM_EDITOR_GRASSGENERATOR       32800
#define IDM_EDITOR_GHOST                32801
#define IDM_EDITOR_GOLD                 32802
#define IDM_EDITOR_VOLCANO              32804
#define IDM_EDITOR_LAVA                 32805
#define IDM_EDITOR_CUT                  32806
#define IDM_EDITOR_BORDER               32807
#define IDM_EDITOR_FILL                 32808
#define IDM_EDITOR_SINGLE               32809
#define IDM_VIEW_TOOLBARON              32810
#define IDM_VIEW_TOOLBAROFF             32811
#define IDM_EDITOR_ROBOT                32812
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         32813
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
